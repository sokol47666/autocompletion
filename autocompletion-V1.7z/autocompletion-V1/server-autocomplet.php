<?php
/**
 * Created by PhpStorm.
 * User: michal
 * Date: 16/11/2014
 * Time: 13:30
 */
$host = "localhost";
$uname = "root";
$pass = "";
$database = "autocomplete";

$connection=mysql_connect($host,$uname,$pass) or die("connection in not ready <br>");
$result=mysql_select_db($database) or die("database cannot be selected <br>");


//SECTION FOR INPUT=NOM -> query
if (isset($_REQUEST['query'])) {
    $query = $_REQUEST['query'];
    $sql = mysql_query ("SELECT * FROM autocomplete.users WHERE nom LIKE  '%{$query}%'");
    $array = array();
    while ($row = mysql_fetch_assoc($sql)) {
        $array[] = $row['nom'];
    }

   // echo var_dump($array);

    echo json_encode ($array); //Return the JSON Array
}

//SECTION FOR INPUT=PRENOM -> query
if (isset($_REQUEST['queryPrenom'])) {
    $query = $_REQUEST['queryPrenom'];
    $sql = mysql_query ("SELECT * FROM autocomplete.users WHERE prenom LIKE  '%{$query}%'");
    $array = array();
    while ($row = mysql_fetch_assoc($sql)) {
        $array[] = $row['prenom'];
    }

    // echo var_dump($array);

    echo json_encode ($array); //Return the JSON Array
}
//// FIN DE SECTION FOR INPUT=PRENOM  -> queryPrenom

//SECTION FOR INPUT=VILLE -> queryVille
if (isset($_REQUEST['queryVille'])) {
    $query = $_REQUEST['queryVille'];
    $sql = mysql_query ("SELECT * FROM autocomplete.users WHERE ville LIKE  '%{$query}%';");
    $array = array();
    while ($row = mysql_fetch_assoc($sql)) {
        $array[] = $row['ville'];
    }

    // echo var_dump($array);

    echo json_encode ($array); //Return the JSON Array
}
//// FIN DE SECTION FOR INPUT=VILLE  -> queryVille



//SECTION FOR INPUT=ASSOCIATION -> queryAssociation
if (isset($_REQUEST['queryAssociation'])) {
    $query = $_REQUEST['queryAssociation'];
    $sql = mysql_query ("SELECT * FROM autocomplete.users WHERE association LIKE  '%{$query}%'");
    $array = array();
    while ($row = mysql_fetch_assoc($sql)) {
        $array[] = $row['association'];
    }

    // echo var_dump($array);

    echo json_encode ($array); //Return the JSON Array
}
//// FIN DE SECTION FOR INPUT=VILLE  -> queryAssociation


